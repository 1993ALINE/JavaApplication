
package bank.account.demo;

public class BankAccount {

    private int accountNumber;
    private String accountName;
    private double balance;

    public BankAccount() {
        accountNumber = 0;
        accountName = "";
        balance = 0;
    }
    

    public BankAccount(int number, String name, double amount) {
        accountNumber = number;
        accountName = name;
        balance = amount;
    }
    
    public String getAccountName() {
        return accountName;
    }
    

    public double getBalance() {
        return balance;
    }
    
    public int getAccountNumber() {
        return accountNumber;
    }
    
    public void deposit(int amount) {
        if (amount > 0)
            balance = balance + amount;
    }
    

    public void withdraw(int amount) {
        if (amount > 0 && amount <= balance)
            balance = balance - amount;
    }
}
