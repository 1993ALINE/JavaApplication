
package bank.account.demo;


public class BankAccountDemo {


    public static void main(String[] args) {

        BankAccount a = new BankAccount(1122, "Md. Ashiqur Rahman", 1000);
        BankAccount b = new BankAccount(3444, "Roksana Akter Jolly", 10000);
        
        a.deposit(1000);
        a.withdraw(200);

        
        System.out.printf("%d %s %.2f\n",
                a.getAccountNumber(),
                a.getAccountName(),
                a.getBalance());

        System.out.printf("%d %s %.2f\n",
                b.getAccountNumber(),
                b.getAccountName(),
                b.getBalance());
    }
    
}
